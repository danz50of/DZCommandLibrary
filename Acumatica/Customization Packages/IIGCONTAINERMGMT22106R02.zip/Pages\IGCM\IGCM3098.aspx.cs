using System;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using IGCM.DAC;
using IGCM;
using PX.Data;
using System.Collections.Generic;

public partial class Page_IGCM3098 : PX.Web.UI.PXPage
{

}